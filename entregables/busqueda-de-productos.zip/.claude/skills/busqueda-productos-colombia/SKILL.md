---
name: "busqueda-productos-colombia"
description: "Encuentra y valida productos para dropshipping contra entrega en Colombia. Úsalo cuando se hable de buscar productos ganadores, revisar la Biblioteca de Anuncios de Meta, validar un candidato, calcular margen contra entrega, o decidir si un producto sirve para vender en Colombia."
---

# Búsqueda y validación de productos para Colombia

Contexto: dropshipper colombiano, vende solo en Colombia, contra entrega,
con Shopify y Dropi.

## Las dos mitades

**Descubrir** es encontrar productos que ya se venden afuera o que resuelven
un problema real de los colombianos.
**Validar** es decidir si sirven en Colombia con contra entrega, sin
saturación y con margen suficiente.

Nunca entregar un candidato sin validarlo. Un producto que arrasa en Estados
Unidos puede ser inviable acá solo por el flete o porque ya está quemado en
TikTok.

Si el producto exacto no tiene proveedor disponible en Colombia (no está en
Dropi ni se puede importar en un plazo razonable), eso no descarta la
oportunidad completa: se busca un producto distinto que resuelva el mismo
problema, con proveedor local, y se pasa por las mismas fases. Lo que
importa es el problema que se resuelve, el producto puntual es reemplazable.

## Filtros antes de invertir tiempo en un candidato

Un producto solo vale la pena revisar a fondo si cumple, o tiene buena
posibilidad de cumplir, estos ocho puntos:

1. Resuelve un problema real del cliente y el beneficio se entiende en pocos
 segundos.
2. Es difícil de conseguir en tiendas físicas comunes (Éxito, D1, Dollarcity,
 Falabella, Alkosto, Homecenter). Si ya está en esas tiendas, solo sigue
 vivo con una razón de peso para comprarlo con nosotros: una promoción más
 fuerte, un combo exclusivo, un beneficio adicional, o una comunicación
 enfocada en un dolor específico que la tienda física no toca.
3. Tiene margen suficiente después de publicidad, logística y devoluciones
 (Fase 3), y el cliente lo percibe como algo que vale más de lo que cuesta.
4. Ya muestra señales de venta en otro lado, sea en anuncios activos o en
 contenido con buena interacción. No se trata de copiar, se trata de
 confirmar que hay demanda antes de invertir en probarlo.
5. Permite armar una marca propia: presentación, mensaje, oferta y si se
 puede, empaque. Evitar productos donde la única guerra posible es de
 precio.
6. Favorece la recompra o la venta complementaria, cuando el producto lo
 permite. No es obligatorio, pero suma.
7. Se puede comprar sin pensarlo mucho. Su utilidad o efecto se entiende de
 un vistazo.
8. Tiene una magnitud de solución al problema (MSP) alta: el dolor que
 resuelve es frecuente, molesto o costoso, la solución se ve rápida y
 sencilla, y el resultado es visible o demostrable.

Los nichos con mejor comportamiento para este modelo son hogar, jardinería,
autos y accesorios, y mascotas. No excluyen otros nichos, pero son el punto
de partida cuando no hay un candidato claro todavía.

## Fase 1 · Descubrimiento

Se trabaja con varias fuentes en paralelo, no una sola.

### Biblioteca de Anuncios de Meta

Punto de entrada principal, filtrando por país. Colombia nunca es país de
descubrimiento, es el mercado donde ya vende.

Dos roles distintos de país, no confundirlos:

- **Señal temprana**: Estados Unidos, Brasil. Muestran tendencias antes que
 nadie.
- **Señal de viabilidad**: México, Perú, Chile. Ingreso y logística parecidos
 a Colombia, así que lo que funciona allá con contra entrega es mucho más
 probable que funcione acá.

Señales a leer en cada anuncio:

| Señal | Qué significa |
|---|---|
| Activo 7 a 30 días con tracción | Oportunidad temprana, el mejor momento |
| Activo más de 60 días | Ya validado, alguien lo escala. Menos riesgo, más competencia |
| Varias variantes creativas del mismo anunciante | Está invirtiendo en serio |
| Pocos anunciantes con el mismo producto | Poco saturado |
| Muchos anunciantes pulidos | Nicho maduro, se llegó tarde |
| Comentarios tipo "¿dónde lo consigo?" | Demanda real |

Pesan más los comentarios y compartidos que los likes. Un video con 3.000
likes y 12 comentarios vende menos que uno con 800 likes y 200 comentarios
preguntando precio.

### TikTok

Buscar el producto o el problema que resuelve y revisar contenido con buena
interacción, comentarios positivos y reseñas favorables.

Ojo con la trampa: muchas reseñas y alta disponibilidad también son señal de
que el producto ya está saturado en Colombia. Antes de darlo por bueno,
revisar:

- Cuántas tiendas colombianas lo están ofreciendo ya.
- Cuántos anuncios activos existen para ese producto.
- Desde hace cuánto tiempo se promociona.
- Si todavía queda un ángulo, un público o una oferta que permita
 diferenciarlo.

### Google Trends, Google Ads y Reddit

Google Trends del término en Colombia sirve para contrastar lo que se ve en
Meta o TikTok: si en Meta sube y en Trends está plano, el producto apenas
arranca; si en Trends ya bajó, se llegó tarde.

El Planificador de Palabras Clave de Google Ads suma otra capa: volumen de
búsqueda del problema (no solo del nombre del producto), estacionalidad, y en
qué regiones de Colombia hay más interés. La investigación arranca mejor por
el problema que por el nombre del producto.

Reddit sirve para escuchar el problema en las palabras reales de quien lo
sufre, casi siempre en inglés. Ahí aparecen quejas, soluciones que la gente
ya probó, objeciones frecuentes, y frases que después sirven para el anuncio
o la página de venta. Lo que se encuentra en Reddit siempre se valida
después contra el mercado colombiano, nunca se da por bueno solo porque
suena bien en inglés.

## Fase 2 · Competencia con DropKiller

Antes de pasar a la matemática de margen, revisar el nivel de competencia
del producto en DropKiller.

- El mercado no debe estar saturado.
- En los últimos 7 días, el producto no debe superar 200 ventas.
- La suma de ventas de todos los competidores y todos los ID asociados al
 mismo producto no debe superar 1.000 ventas.
- Si esa suma pasa de 1.000, se descarta para no entrar a un mercado ya
 repartido.

Nunca evaluar un solo anuncio o ID por separado. Hay que sumar todos los ID
y competidores del mismo producto antes de decidir.

## Fase 3 · Validación: la matemática manda

Si los números no dan, el producto se descarta aunque el video sea
espectacular.

### Modelo, por cada 100 pedidos despachados

```
Entregados        = 100 × tasa de efectividad
Ingreso           = entregados × precio de venta
Costo producto    = entregados × costo unitario
Flete de ida      = 100 × flete
Flete devolución  = (100 − entregados) × flete devolución
Publicidad        = 100 × CPA        (se paga por pedido generado, entregue o no)
Comisión          = entregados × (precio × % plataforma)

Utilidad = Ingreso − producto − flete ida − flete devolución − publicidad − comisión
Margen   = Utilidad / Ingreso
```

El error más común es calcular sobre una venta entregada e ignorar que los
pedidos fallidos ya consumieron flete y publicidad. Nunca calcular así.

### Rangos de referencia para Colombia

Son estimaciones de mercado, no datos de su operación. Cuando el usuario
tenga números reales de sus ventas, esos mandan. Marcar siempre qué es
estimación.

| Variable | Rango | Por defecto |
|---|---|---|
| Tasa de efectividad | 65% a 83% | 75% |
| Flete por envío | 10.000 a 25.000 COP | 15.000 |
| Comisión de plataforma | 3% a 7% | 5% |
| CPA en LatAm | 15.000 a 30.000 COP | 20.000 |
| Precio de venta viable | 60.000 a 150.000 COP | — |
| Margen neto mínimo | 25% | — |

### Descarte automático

Se descarta sin discusión si:

- Margen neto a 75% de efectividad por debajo de 25%.
- Precio de venta viable por debajo de 50.000 COP. El flete y el CPA se lo
 comen.
- **Réplicas, imitaciones o cualquier producto que use una marca ajena.**
 Meta tumba la cuenta publicitaria y Shopify cierra la tienda por
 infracción de marca. Que alguien lo esté anunciando solo significa que
 todavía no lo han detectado.
- Pesado o voluminoso. El flete lo mata.
- Frágil. Las devoluciones por daño destruyen la efectividad.
- Depende de talla o color exacto. Multiplica devoluciones en contra
 entrega.
- La suma de ventas en DropKiller (Fase 2) pasa de 1.000.
- Electrónico con garantía compleja o que puede llegar fallando.
- Promete resultados de salud. Problemas con Meta y con el cliente.

Se consigue fácil en tienda física (Éxito, D1, Dollarcity, Falabella,
Alkosto, Homecenter) es descarte por defecto. Pasa a OBSERVAR solo si hay
una diferenciación concreta y ya definida: combo exclusivo, promoción más
fuerte, beneficio adicional o ángulo de comunicación que la tienda física no
puede igualar. Sin esa diferenciación clara, se descarta igual (ver también
validacion-retail-colombia).

**Sin proveedor local no es descarte del problema.** Si el candidato pasa
todos los filtros pero no hay forma de conseguirlo en Colombia a tiempo
razonable, no se cierra la búsqueda: se busca otro producto que resuelva el
mismo problema y sí tenga proveedor en Dropi o importación viable, y ese
reemplazo se pasa de nuevo por Fase 2 y Fase 3 antes de darlo por bueno.

## Fase 4 · La ficha del candidato

Todo candidato se entrega así, sin excepción:

**1. Producto** — qué es, en una línea. Foto o enlace al anuncio.

**2. Dónde se encontró** — país, anunciante, días activo, número de
variantes, enlace directo al anuncio.

**3. Señales** — qué se vio en engagement y comentarios, qué dijo la
segunda fuente (Trends, TikTok o Reddit).

**4. Competencia en DropKiller** — ventas de los últimos 7 días y suma
total con todos los ID relacionados.

**5. Números** — costo estimado, precio propuesto, y la tabla de margen a
70%, 75% y 80% de efectividad. Las tres, no solo una.

**6. MSP y diferenciación** — qué tan grande es el problema que resuelve,
y si aplica, cuál es la diferenciación frente a lo que ya existe en retail
o en otros anunciantes.

**7. Proveedor** — si está en Dropi, si toca importar, o si no hay forma
razonable de conseguirlo. En este último caso, cuál fue el producto
alternativo que se buscó para resolver el mismo problema en su lugar.

**8. Veredicto** — VALIDAR, OBSERVAR o DESCARTAR, con la razón en una
línea. Si es DESCARTAR, decirlo de una y no adornarlo.

**9. Solo si es VALIDAR** — ángulo de venta y para quién, las tres
objeciones más probables del comprador colombiano, y qué probar primero
(creativo, precio o ángulo).

## Cómo se busca en la práctica

1. Preguntar país si no lo dice, sugiriendo según el rol que quiera: señal
 temprana o señal de viabilidad. Si no hay candidato claro todavía,
 empezar por los nichos prioritarios (hogar, jardinería, autos y
 accesorios, mascotas).
2. Abrir la Biblioteca de Anuncios de Meta en el navegador, filtrar por país
 y categoría, ordenar por más recientes. En paralelo, revisar TikTok con
 el nombre del producto o del problema.
3. Recorrer resultados y quedarse con los que cumplan los filtros iniciales
 y las señales de Fase 1.
4. Contrastar con Google Trends, el Planificador de Palabras Clave y, si el
 nicho lo pide, con Reddit para entender el problema en palabras del
 consumidor.
5. Revisar competencia en DropKiller (Fase 2). El que pase de 1.000 ventas
 sumadas, se cae aquí.
6. Pasar cada uno por Fase 3. La mayoría se cae ahí, y está bien.
7. Confirmar proveedor en Colombia (Dropi o importación viable). Si no hay,
 buscar el reemplazo que resuelve el mismo problema antes de seguir.
8. Entregar solo los que sobrevivan, con ficha completa (Fase 4).

Mejor tres candidatos con ficha sólida que veinte nombres sueltos.

## Lista rápida de verificación

Antes de entregar un candidato como VALIDAR:

- [ ] Resuelve un problema real y el beneficio se entiende en pocos
 segundos.
- [ ] Es difícil de conseguir en tienda física, o tiene diferenciación
 clara si ya está.
- [ ] El margen a 75% de efectividad supera 25%.
- [ ] El cliente lo percibe como algo que vale más de lo que cuesta.
- [ ] Ya hay señales comprobables de venta en otro lado.
- [ ] Se puede armar marca propia con él.
- [ ] Favorece una compra poco planeada.
- [ ] La demanda tiene relevancia para Colombia (Trends, Keyword Planner o
 Reddit contrastado).
- [ ] Cumple los límites de competencia de DropKiller.
- [ ] Hay proveedor real en Colombia, propio o de reemplazo.
- [ ] Existe un ángulo de venta distinto al de los competidores.

## Escritura

Textos humanizados, sin marcas de escritura de IA: sin rayas largas, sin
"no es X sino Y", sin regla de tres, sin frases que terminan en gerundio, sin
vocabulario tipo potenciar, integral, panorama, robusto, elevar, y sin
lenguaje promocional inflado.