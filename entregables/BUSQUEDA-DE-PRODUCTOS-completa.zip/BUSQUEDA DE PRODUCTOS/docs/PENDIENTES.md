# Pendientes

## Por definir en el método nuevo
- Umbral de impresiones que cuenta como "bueno".
- Días mínimos en circulación para llamar "validado" a un creativo.
- Qué es un "despliegue importante" (número de variantes, anuncios activos, etc.).
- Nombres finales de los métodos. Propuesta: "Método Landings Ganadoras" (nuevo) y "Método Mentor" (anterior).

## Acceso
- Desde la nube, Claude no pudo abrir facebook.com, ppspy.com, tiktok.com ni app.dropi.co (la red del entorno los bloquea).
- Para que Claude busque solo, abrir la carpeta en Claude Code en el computador (con tu navegador y sesiones) o pegar las landings encontradas.

## Primera búsqueda
- Elegir un dolor, buscar en la Biblioteca de Anuncios (todos los países, ordenar por impresiones), registrar las landings en el Excel y seguir los pasos 2 a 5 del skill.
