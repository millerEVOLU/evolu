# Búsqueda de productos EVOLU

Dropshipping contra entrega solo en Colombia, con Shopify y Dropi.

## Qué método usar

- **Método nuevo (por defecto):** skill `busqueda-productos-mercado-internacional`. Se parte de landings ganadoras en la Biblioteca de Anuncios de Meta, se guardan en el Excel, se sacan los best winners con PPSPY y se analiza la competencia a fondo.
- **Recomendaciones del mentor (referencia):** skill `busqueda-productos-colombia`. Se usa como apoyo de validación: DropKiller, matemática de margen y revisión de retail.

Si los dos dan señales distintas sobre un mismo producto, se revisa a mano y se anota el motivo.

## Reglas que no se negocian

- Landings con más de 600 productos y productos de menos de 10 meses que posiblemente estén en Dropi. Si cumple, se deja la landing y se sigue buscando más.
- Unos 20 best winners por página en PPSPY. Al final quedan uno o dos que pasen los filtros.
- Competencia: solo cuentan las landings activas. WhatsApp y landings apagadas no compiten. Se revisa a fondo y se repite la búsqueda antes de dar un número.
- Hasta 5 competidores no descartan el producto si se vende con otro ángulo.
- Las tiendas de Shanghái son muy buenas. Abrirse a más países.
- Los dolores de ejemplo (acné, artritis, pantallas y niños) no son los únicos.
- Nunca entregar un candidato sin validarlo. Sin datos reales de la Biblioteca o de PPSPY no se inventa un producto.

## Archivos

- `excel/EVOLU_Banco_Productos.xlsx`: banco de landings, productos, competencia, finalistas y margen.
- `docs/PENDIENTES.md`: lo que falta definir.

## Estilo

Textos humanizados, sin marcas de escritura de IA: sin rayas largas, sin "no es X sino Y", sin regla de tres, sin gerundios al final de frase y sin lenguaje promocional inflado.
